import "../App.css";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const DashBoard = () => {
    const { id } = useParams();
    const [posts, setPosts] = useState([]);
    const [userDetail, setUserDetail] = useState(null);
    const [totalPosts, setTotalPosts] = useState(0);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchPosts = async () => {
            try {
                const response = await fetch(`http://127.0.0.1:8000/blog/posts/?author=${id}`, {
                    method: 'GET',
                });
                if (response.ok) {
                    const data = await response.json();
                    if (data.results && Array.isArray(data.results)) {
                        setPosts(data.results);
                        setTotalPosts(data.count || data.results.length);
                    } else {
                        console.error("Unexpected data structure:", data);
                        setPosts([]);
                        setTotalPosts(0);
                    }
                } else {
                    console.error("Error fetching posts:", response.statusText);
                }
            } catch (error) {
                console.error("Network error:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchPosts();
    }, [id]);

    useEffect(() => {
        const accessToken = sessionStorage.getItem('access_token'); // Correct key name?
        const fetchUser = async () => {
            try {
                const response = await fetch(`http://127.0.0.1:8000/blog/users/${id}`, {
                    method: "GET",
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${accessToken}`,
                    },
                });
                if (response.ok) {
                    const data = await response.json();
                    setUserDetail(data);
                } else {
                    console.error("Error fetching user details:", response.statusText);
                }
            } catch (error) {
                console.error("Network error:", error);
            }
        };
        fetchUser();
    }, [id]);

    return (
        <div style={{ padding: "20px", maxWidth: "800px", margin: "0 auto" }}>
            <h1>Dashboard</h1>
            <h2>User Details:</h2>
            {userDetail ? (
                <div>
                    <p>Name: {userDetail.name}</p>
                    <p>Email: {userDetail.email}</p>
                </div>
            ) : (
                <p>Loading user details...</p>
            )}
            <h2>Posts:</h2>
            {loading ? (
                <p>Loading posts...</p>
            ) : (
                posts.length > 0 ? (
                    posts.map((post) => (
                        <div key={post.id} style={{ marginBottom: "20px", border: "1px solid #ddd", borderRadius: "8px", padding: "20px", backgroundColor: "#f9f9f9" }}>
                            <h1>{post.title}</h1>
                            <p style={{ color: "#666", fontSize: "14px" }}>
                                Published on {new Date(post.created_at).toLocaleDateString()}
                            </p>
                            <div
                                className="blog-post-content"
                                style={{
                                    marginTop: "20px",
                                    fontSize: "16px",
                                    lineHeight: "1.6",
                                }}
                                dangerouslySetInnerHTML={{ __html: post.content }}
                            />
                        </div>
                    ))
                ) : (
                    <p>No posts found.</p>
                )
            )}
        </div>
    );
};

export default DashBoard;
